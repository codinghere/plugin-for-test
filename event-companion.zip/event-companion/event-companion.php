<?php
/*
 * Plugin Name: Event Companion Plugin
 * Plugin URI:
 * Description: Companion Plugin for event Theme
 * Version:1.0
 * Author: AAS
 * Author URI: themelooks.com
 * License:GPLv2 or later
 * Text Domain: event-companion
 * Domain Path: /languages/
 */

function eventc_load_text_domain()
{
    load_plugin_textdomain('event-companion', false, dirname(__FILE__) . "/languages");
}

add_action('plugin_loaded', 'eventc_load_text_domain');

function eventc_register_my_cpts_section()
{

    /**
     * Post Type: Sections.
     */

    $labels = [
        "name"          => __("Sections", "event-companion"),
        "singular_name" => __("Section", "event-companion"),
    ];

    $args = [
        "label"               => __("Sections", "event-companion"),
        "labels"              => $labels,
        "description"         => "",
        "public"              => false,
        "publicly_queryable"  => false,
        "show_ui"             => true,
        "show_in_rest"        => false,
        "rest_base"           => "",
        "has_archive"         => false,
        "show_in_nav_menus"   => true,
        "delete_with_user"    => false,
        "exclude_from_search" => true,
        "capability_type"     => "post",
        "map_meta_cap"        => true,
        "hierarchical"        => false,
        "rewrite"             => ["slug" => "section", "with_front" => true],
        "query_var"           => true,
        "menu_position"       => 5,
        "menu_icon"           => "dashicons-media-document",
        "supports"            => ["title", "editor", "thumbnail"],// taxonomy array and this '[]' also are array
        "taxonomies"          =>array('category')
    ];

    register_post_type("section", $args);




//    reripes cpt
    $labels = [
        "name"          => __("Schedule", "event-companion"),
        "singular_name" => __("Schedule", "event-companion"),
        "featured_image"=>__("Schedule image","event companion")
    ];

    $args = [
        "label"                 => __("Schedule", "event-companion"),
        "labels"                => $labels,
        "description"           => "",
        "public"                => true,
        "publicly_queryable"    => true,
        "show_ui"               => true,
        "show_in_rest"          => true,
        "rest_base"             => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "has_archive"           => false,
        "show_in_menu"          => true,
        "show_in_nav_menus"     => true,
        "delete_with_user"      => false,
        "exclude_from_search"   => false,
        "capability_type"       => "post",
        "map_meta_cap"          => true,
        "hierarchical"          => false,
        "rewrite"               => ["slug" => "schedule", "with_front" => true],
        "query_var"             => true,
        "menu_position"         => 5,
        "menu_icon"             => "dashicons-carrot",
        "supports"              => ["title", "editor", "thumbnail","excerpt"],
        "show_in_graphql"       => false,
        "taxonomies"            =>array('category')
    ];

    register_post_type("schedule", $args);


}

add_action('init', 'eventc_register_my_cpts_section');

//function eventc_transient_demo(){
//    set_transient('res_count',34,20);
//}
//
//add_action('init','eventc_transient_demo');